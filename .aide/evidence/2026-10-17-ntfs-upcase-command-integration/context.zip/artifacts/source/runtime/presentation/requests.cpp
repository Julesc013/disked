#include "requests.h"
#include <mutex>
#include <thread>
#include <condition_variable>

namespace disked {
void PendingRequestView::begin(const std::string& id, std::uint64_t view) {
    if (!id_.empty()) {
        throw std::runtime_error("frontend_pending_limit");
    }
    if (id.empty()) {
        throw std::runtime_error("frontend_completion_identity");
    }
    id_ = id;
    submitted_view_ = view;
}

RequestDelivery PendingRequestView::poll(const CompletionPoll& callback, std::uint64_t view,
                                        Outcome& output) {
    Outcome received;
    if (!callback || !callback(received)) {
        return RequestDelivery::NoResult;
    }
    const auto* id = received.response.find("request_id");
    if (id_.empty() || !id || id->kind != json::Value::Kind::string || id->text != id_) {
        throw std::runtime_error("frontend_completion_identity");
    }
    const auto delivery = submitted_view_ == view ? RequestDelivery::CurrentView
                                                : RequestDelivery::EarlierView;
    output = std::move(received);
    id_.clear();
    return delivery;
}

struct RequestChannel::State {
    std::mutex mutex;
    std::condition_variable changed;
    bool busy=false,ready=false;
    Outcome result;
};
namespace {
Outcome unresolved(const std::string& request,const std::string& reason) {
    auto value=completed(request,json::Value{});value.exit_code=6;
    value.response.put("status",json::Value::string("unknown"));
    value.response.fields["diagnostics"].items.push_back(diagnostic(reason));return value;
}
}
RequestChannel::RequestChannel():state_(std::make_shared<State>()) {}
Submission RequestChannel::submit(const std::string& request,std::function<Outcome()> callback,std::size_t response_bytes,Outcome fallback) {
    // Existing lanes retain their one-MiB ceiling. The recursive composition
    // selects one exact larger lane for a bounded record batch plus observation.
    if(!response_bytes || (response_bytes>1048575 && response_bytes!=2097151))return refused(request,"request_resource_limit",3);
    const auto state=state_;
    std::lock_guard<std::mutex> lock(state->mutex);
    if(state->busy)return refused(request,"request_resource_limit",3);
    state->busy=true;
    try {
        // Reserve failure receipts before admitting the callback. Reporting an
        // allocation failure must not itself require another allocation in the
        // background thread or let an exception escape and terminate the UI.
        auto failure=fallback.response.kind==json::Value::Kind::null?unresolved(request,"request_completion_unresolved"):std::move(fallback);
        const auto* selected=failure.response.find("request_id"),*status=failure.response.find("status");
        if(failure.exit_code!=6 || !selected || selected->kind!=json::Value::Kind::string || selected->text!=request ||
           !status || status->kind!=json::Value::Kind::string || status->text!="unknown" || !validate_response(failure.response).empty()) {state->busy=false;return refused(request,"request_resource_limit",3);}
        auto bounds=response_limits(failure.response);bounds.bytes=response_bytes;json::dump(failure.response,bounds);
        failure.response.fields["diagnostics"]=json::Value::array();failure.response.fields["diagnostics"].items.push_back(diagnostic("request_completion_unresolved"));
        auto invalid=failure;invalid.response.fields["diagnostics"].items.front()=diagnostic("request_completion_invalid");
        std::thread([state,request,callback,response_bytes,failure=std::move(failure),invalid=std::move(invalid)]() mutable {
            Outcome result=std::move(failure);
            try {
                auto candidate=callback();
                // The single result slot has the public frame bound and exact
                // correlation. A malformed/oversized reply cannot imply no effect.
                const auto* id=candidate.response.find("request_id");
                if(!id || id->kind!=json::Value::Kind::string || id->text!=request || !validate_response(candidate.response).empty())
                    result=std::move(invalid);
                else {
                    try {auto limits=response_limits(candidate.response);limits.bytes=response_bytes;json::dump(candidate.response,limits);result=std::move(candidate);}
                    catch(...) {
                        // The correlated envelope has already validated its ID.
                        // Preserve an observed allocated ID on a budget failure;
                        // never replace a separately selected operation identity.
                        auto known=candidate.response.fields.find("operation_id"),selected=result.response.fields.find("operation_id");
                        if(known!=candidate.response.fields.end() && selected!=result.response.fields.end() && known->second.kind==json::Value::Kind::string &&
                           !known->second.text.empty() && known->second.text.size()<=128 && json::valid_utf8(known->second.text) && known->second.text.find('\0')==std::string::npos &&
                           (selected->second.kind==json::Value::Kind::null || selected->second.text==known->second.text))selected->second=std::move(known->second);
                    }
                }
            } catch(...) {} // Preserve the preallocated unknown outcome.
            std::lock_guard<std::mutex> done(state->mutex);
            state->result=std::move(result);state->ready=true;state->changed.notify_one();
        }).detach();
    } catch(...) {state->busy=false;return refused(request,"request_thread_unavailable",3);}
    return Submission::deferred();
}
bool RequestChannel::poll(Outcome& output) {
    std::lock_guard<std::mutex> lock(state_->mutex);
    if(!state_->ready)return false;
    output=std::move(state_->result);state_->result=Outcome{};state_->ready=state_->busy=false;return true;
}
bool RequestChannel::wait(Outcome& output,std::chrono::milliseconds duration) {
    std::unique_lock<std::mutex> lock(state_->mutex);
    if(!state_->changed.wait_for(lock,duration,[&] {return state_->ready;}))return false;
    output=std::move(state_->result);state_->result=Outcome{};state_->ready=state_->busy=false;return true;
}
Outcome BoundedRequests::run(const std::string& request,std::function<Outcome()> callback,
    Outcome expired,std::chrono::milliseconds duration,const std::function<bool()>& progress,std::size_t response_bytes) {
    Outcome result;
    if(late_) {
        if(!channel_.poll(result))return refused(request,"request_resource_limit",3);
        // The previous exchange already received unknown. Durable operation
        // state is still in its explicit store; this late observation is neither
        // a second wire response nor proof of worker quiescence.
        late_=false;
    }
    auto submission=channel_.submit(request,std::move(callback),response_bytes,expired);
    if(!submission.pending)return std::move(submission.outcome);
    if(!progress) {if(channel_.wait(result,duration))return result;}
    else {
        const auto end=std::chrono::steady_clock::now()+duration;
        do {
            if(!progress()) {late_=true;return refused(request,"output_error",4);}
            if(channel_.wait(result,std::chrono::milliseconds(10))) {
                if(!progress())return refused(request,"output_error",4);return result;
            }
        } while(std::chrono::steady_clock::now()<end);
    }
    late_=true;return expired;
}
}
