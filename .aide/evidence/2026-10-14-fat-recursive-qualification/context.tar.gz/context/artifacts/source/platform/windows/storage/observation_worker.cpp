#include "observation_worker.h"
#include "platform/windows/worker_files.h"
#include <cstddef>
#include <cstring>
#include <set>
namespace disked { namespace nt_inventory {
namespace {
using V=json::Value;using namespace worker_files;
struct Input {DWORD length;};
struct Output {volatile LONG ready,entered;DWORD length;char digest[64];};
static_assert(sizeof(Input)==4 && sizeof(Output)==76,"selected reader header ABI");
struct View {
    void* value=nullptr;
    View(HANDLE file,DWORD access,std::size_t bytes) {value=MapViewOfFile(file,access,0,0,bytes);if(!value)fail("observation_mapping_unavailable");}
    ~View(){if(value)UnmapViewOfFile(value);}View(const View&)=delete;View& operator=(const View&)=delete;
};
const V& field(const V& v,const char* k){const auto p=v.find(k);if(!p)throw std::invalid_argument("observation_shape");return *p;}
void exact(const V& v,const std::set<std::string>& keys){if(v.kind!=V::Kind::object || v.fields.size()!=keys.size())throw std::invalid_argument("observation_shape");for(const auto& x:v.fields)if(!keys.count(x.first))throw std::invalid_argument("observation_shape");}
std::uint64_t integer(const V& x){if(x.kind!=V::Kind::string || !json::decimal_u64(x.text))throw std::invalid_argument("observation_integer");return std::stoull(x.text);}
V number(std::uint64_t n){return V::string(std::to_string(n));}
[[noreturn]] void invalid(const ObservationWorkerProfile& p,const char* why){throw std::invalid_argument(std::string(p.prefix)+"_"+why);}
void request(const V& r,const ObservationWorkerProfile& p){
    exact(r,{"capture_epoch","policy","provider_input"});if(!integer(field(r,"capture_epoch")) || field(r,"provider_input").kind!=V::Kind::object)invalid(p,"request");
    json::dump(field(r,"provider_input"),p.provider_limits);p.validate_request(r);
}
void header(const V& h,const ObservationWorkerProfile& p){
    exact(h,{"schema","scope","host_id","code_sha256","capture_epoch","observer_epoch","worker_epoch","attempt_id","policy","provider_input"});
    if(text(h,"schema")!=p.input_schema || text(h,"scope")!=p.scope)invalid(p,"scope");
    for(const auto k:{"host_id","code_sha256","observer_epoch","worker_epoch","attempt_id"})if(text(h,k).empty())invalid(p,"binding");
    auto r=V::object();for(const auto k:{"capture_epoch","policy","provider_input"})r.put(k,field(h,k));request(r,p);
}
Handle section(const Security& s,std::size_t bytes){auto a=s.attributes;Handle h(CreateFileMappingW(INVALID_HANDLE_VALUE,&a,PAGE_READWRITE,0,static_cast<DWORD>(bytes),nullptr));if(!h.valid())fail("observation_mapping_create");return h;}
Handle event(const Security& s){auto a=s.attributes;Handle h(CreateEventW(&a,TRUE,FALSE,nullptr));if(!h.valid())fail("observation_event_create");return h;}
void signal(HANDLE h){if(!SetEvent(h))fail("observation_event_signal");}
V permissions(const ObservationWorkerProfile& profile){auto out=V::object().put("live_namespace",V::boolean_value(false)).put("physical_admission",V::boolean_value(false)).put("mutation_authority",V::boolean_value(false)).put("durable_reconnect",V::boolean_value(false));if(profile.compiled_effects_capable)out.put("compiled_effects_capable",V::boolean_value(true));return out;}
}
struct ObservationWorker::Impl {
    Security security;Image image;Directory code_parent;WorkerBudget aggregate;
    ObservationWorkerProfile profile;Handle input,output,cancellation,admission,gate,job,process,payload;std::unique_ptr<View> view;
    V binding;std::string input_digest,created,last_bytes;DWORD pid=0;bool cancellation_requested=false,retired=false,launch_attempted=false;
    explicit Impl(const ObservationWorkerProfile& p):code_parent(narrow(image.path.substr(0,image.path.find_last_of(L'\\')))),aggregate(security,true),profile(p){}
};
ObservationWorker::ObservationWorker(std::unique_ptr<Impl> p):impl_(std::move(p)){}
ObservationWorker::~ObservationWorker()=default;
const V& ObservationWorker::binding() const{return impl_->binding;}
std::unique_ptr<ObservationWorker> ObservationWorker::prepare(const V& r,const ObservationWorkerProfile& profile,HANDLE payload){
    request(r,profile);if(profile.input_mapping_bytes<sizeof(Input) || profile.input_mapping_bytes>278528 || profile.input_limits.bytes>profile.input_mapping_bytes-sizeof(Input) || profile.reply_limits.bytes>786432)invalid(profile,"profile");
    if(profile.payload_bytes>16U*1024U*1024U || ((payload && payload!=INVALID_HANDLE_VALUE)!=bool(profile.payload_bytes)))invalid(profile,"payload_profile");
    std::unique_ptr<Impl> p(new Impl(profile));p->binding=r;
    if(profile.payload_bytes){
        HANDLE owned=nullptr;if(!DuplicateHandle(GetCurrentProcess(),payload,GetCurrentProcess(),&owned,FILE_MAP_READ|FILE_MAP_WRITE,FALSE,0))fail("observation_payload_duplicate");
        p->payload=Handle(owned);View check(p->payload.value,FILE_MAP_READ,profile.payload_bytes);
    }
    p->binding.put("schema",V::string(profile.input_schema)).put("scope",V::string(profile.scope)).put("host_id",V::string(p->security.host_id)).put("code_sha256",V::string(p->image.digest))
        .put("observer_epoch",V::string(p->security.identity("observer:"))).put("worker_epoch",V::string(p->security.identity("worker:"))).put("attempt_id",V::string(p->security.identity(profile.attempt_prefix)));
    const auto bytes=json::dump(p->binding,profile.input_limits);p->input_digest=hash(bytes);
    p->input=section(p->security,profile.input_mapping_bytes);p->output=section(p->security,sizeof(Output)+profile.reply_limits.bytes);
    {View v(p->input.value,FILE_MAP_WRITE,profile.input_mapping_bytes);auto target=static_cast<Input*>(v.value);target->length=static_cast<DWORD>(bytes.size());std::memcpy(target+1,bytes.data(),bytes.size());}
    p->view.reset(new View(p->output.value,FILE_MAP_READ,sizeof(Output)+profile.reply_limits.bytes));
    p->cancellation=event(p->security);p->admission=event(p->security);p->gate=event(p->security);
    auto a=p->security.attributes;p->job=Handle(CreateJobObjectW(&a,nullptr));if(!p->job.valid())fail("observation_job_create");
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_ACTIVE_PROCESS|JOB_OBJECT_LIMIT_PROCESS_MEMORY|JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    limits.BasicLimitInformation.ActiveProcessLimit=1;limits.ProcessMemoryLimit=128*1024*1024;
    if(!SetInformationJobObject(p->job.value,JobObjectExtendedLimitInformation,&limits,sizeof(limits)))fail("observation_job_limits");
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION observed{};
    if(!QueryInformationJobObject(p->job.value,JobObjectExtendedLimitInformation,&observed,sizeof(observed),nullptr) || observed.BasicLimitInformation.LimitFlags!=limits.BasicLimitInformation.LimitFlags || observed.BasicLimitInformation.ActiveProcessLimit!=1 || observed.ProcessMemoryLimit!=128*1024*1024)fail("observation_job_limits_mismatch");
    return std::unique_ptr<ObservationWorker>(new ObservationWorker(std::move(p)));
}
bool ObservationWorker::never_launched() const{return !impl_->process.valid();}
void ObservationWorker::launch(){
    auto& p=*impl_;if(p.launch_attempted)invalid(p.profile,"launch_reused");p.launch_attempted=true;
    auto ci=inherited(p.input.value,FILE_MAP_READ),co=inherited(p.output.value,FILE_MAP_WRITE),cc=inherited(p.cancellation.value,SYNCHRONIZE),ca=inherited(p.admission.value,EVENT_MODIFY_STATE),cg=inherited(p.gate.value,SYNCHRONIZE);
    Handle cp;if(p.profile.payload_bytes)cp=inherited(p.payload.value,FILE_MAP_WRITE);
    std::vector<HANDLE> handles={ci.value,co.value,cc.value,ca.value,cg.value},jobs={p.aggregate.job.value,p.job.value};if(cp.valid())handles.push_back(cp.value);AttributeList attributes(handles,jobs);
    STARTUPINFOEXW startup{};startup.StartupInfo.cb=sizeof(startup);startup.StartupInfo.dwFlags=STARTF_USESTDHANDLES;startup.lpAttributeList=attributes.list;
    startup.StartupInfo.hStdInput=INVALID_HANDLE_VALUE;startup.StartupInfo.hStdOutput=INVALID_HANDLE_VALUE;startup.StartupInfo.hStdError=INVALID_HANDLE_VALUE;
    std::wstring command=L"\""+p.image.path+L"\" "+p.profile.role;for(const auto h:handles)command+=L" "+std::to_wstring(reinterpret_cast<std::uintptr_t>(h));
#if defined(DISKED_NT_NAMESPACE_WORKER_TESTING) || defined(DISKED_NT_OBSERVATION_WORKER_TESTING)
    const auto fault=field(p.binding,"provider_input").find("startup_fault");const auto mode=fault?fault->text:"";
    if(mode=="before_spawn")throw std::runtime_error("observation_startup_fixture_before_spawn");
#endif
    p.code_parent.check();PROCESS_INFORMATION raw{};
    if(!CreateProcessW(p.image.path.c_str(),&command[0],nullptr,nullptr,TRUE,DETACHED_PROCESS|EXTENDED_STARTUPINFO_PRESENT,nullptr,p.code_parent.path.c_str(),&startup.StartupInfo,&raw))fail("observation_spawn_failed");
    // Store ownership immediately, before any identity lookup or allocation.
    p.process=Handle(raw.hProcess);Handle thread(raw.hThread);p.pid=raw.dwProcessId;
#if defined(DISKED_NT_NAMESPACE_WORKER_TESTING) || defined(DISKED_NT_OBSERVATION_WORKER_TESTING)
    if(mode=="after_spawn")throw std::runtime_error("observation_startup_fixture_after_spawn");
    if(mode=="after_spawn_alloc")throw std::bad_alloc();
#endif
    p.created=process_created(p.process.value);
}
void ObservationWorker::release(){if(never_launched())invalid(impl_->profile,"not_launched");signal(impl_->gate.value);}
void ObservationWorker::cancel(){signal(impl_->cancellation.value);impl_->cancellation_requested=true;}
bool ObservationWorker::wait_entered(DWORD ms){
    if(ms>1000)invalid(impl_->profile,"wait_budget");if(never_launched())return false;const auto end=GetTickCount64()+ms;
    for(;;){MemoryBarrier();if(static_cast<const Output*>(impl_->view->value)->entered)return true;if(WaitForSingleObject(impl_->process.value,0)!=WAIT_TIMEOUT || GetTickCount64()>=end)return false;Sleep(1);}
}
V ObservationWorker::observe(DWORD ms){
    if(ms>1000)invalid(impl_->profile,"wait_budget");auto& p=*impl_;const auto wait=p.process.valid()?WaitForSingleObject(p.process.value,ms):WAIT_FAILED;
    const std::string state=never_launched()?"not_started":wait==WAIT_OBJECT_0?"exited":wait==WAIT_TIMEOUT?"running":"unavailable";
    DWORD exit=STILL_ACTIVE;if(p.process.valid() && !GetExitCodeProcess(p.process.value,&exit))exit=STILL_ACTIVE;
    std::string identity_error;
    if(p.process.valid() && p.created.empty())try{p.created=process_created(p.process.value);}catch(const std::exception& e){identity_error=e.what();}
    auto out=V::object().put("schema",V::string(p.profile.observation_schema)).put("status",V::string(state=="running"?"accepted_running":"unknown"))
        .put("attempt_id",field(p.binding,"attempt_id")).put("capture_epoch",field(p.binding,"capture_epoch")).put("observer_epoch",field(p.binding,"observer_epoch"))
        .put("worker_epoch",field(p.binding,"worker_epoch")).put("request_digest",V::string(p.input_digest)).put("code_sha256",field(p.binding,"code_sha256"))
        .put("worker",V::object().put("pid",number(p.pid)).put("created",V::string(p.created)).put("observation",V::string(state)).put("exit_code",number(exit)))
        .put("admitted",V::boolean_value(WaitForSingleObject(p.admission.value,0)==WAIT_OBJECT_0)).put("cancellation_requested",V::boolean_value(p.cancellation_requested))
        .put("retired",V::boolean_value(p.retired)).put("result",V{}).put("diagnostic",identity_error.empty()?V{}:V::string(identity_error)).put("claims",permissions(p.profile));
    try{
        const auto* value=static_cast<const Output*>(p.view->value);MemoryBarrier();const auto ready=value->ready;MemoryBarrier();
        if(!ready)return out;if(ready!=1 || !value->length || value->length>p.profile.reply_limits.bytes)invalid(p.profile,"publication");
        const std::string bytes(reinterpret_cast<const char*>(value+1),value->length),digest(value->digest,64);MemoryBarrier();
        if(value->ready!=ready || value->length!=bytes.size() || hash(bytes)!=digest)invalid(p.profile,"publication_digest");
        if(!p.last_bytes.empty() && p.last_bytes!=bytes)invalid(p.profile,"reply_changed");
        const auto reply=json::parse(bytes,p.profile.reply_limits);exact(reply,{"schema","scope","host_id","code_sha256","capture_epoch","observer_epoch","worker_epoch","attempt_id","request_digest","pid","created","snapshot"});
        if(text(reply,"schema")!=p.profile.reply_schema || text(reply,"scope")!=p.profile.scope || text(reply,"request_digest")!=p.input_digest || integer(field(reply,"pid"))!=p.pid || text(reply,"created")!=p.created)invalid(p.profile,"reply_binding");
        for(const auto k:{"host_id","code_sha256","capture_epoch","observer_epoch","worker_epoch","attempt_id"})if(text(reply,k)!=text(p.binding,k))invalid(p.profile,"reply_binding");
        const auto& snapshot=field(reply,"snapshot");p.profile.validate_result(snapshot,p.binding);
        p.last_bytes=bytes;out.put("status",V::string("completed")).put("result",snapshot);
    }catch(const std::exception& error){out.put("status",V::string("unknown")).put("diagnostic",V::string(error.what()));if(!p.last_bytes.empty())out.put("last_validated_result",field(json::parse(p.last_bytes,p.profile.reply_limits),"snapshot"));}
    return out;
}
V ObservationWorker::retire(DWORD ms){
    if(ms>2000)invalid(impl_->profile,"retirement_budget");auto& p=*impl_;
    if(p.process.valid() && WaitForSingleObject(p.process.value,0)==WAIT_TIMEOUT){if(!TerminateJobObject(p.job.value,31))fail("observation_retirement_unresolved");p.retired=true;}
    if(p.process.valid())WaitForSingleObject(p.process.value,ms);return observe();
}
int observation_worker_role(int argc,wchar_t** argv,const ObservationWorkerProfile& profile,const PayloadObservationFactory& factory){
    if(profile.payload_bytes>16U*1024U*1024U || argc!=(profile.payload_bytes?8:7))return 2;
    try{
        auto hi=Handle(argument_handle(argv[2])),ho=Handle(argument_handle(argv[3])),hc=Handle(argument_handle(argv[4])),ha=Handle(argument_handle(argv[5])),hg=Handle(argument_handle(argv[6]));
        Security security;WorkerBudget budget(security,false);Image image;View input(hi.value,FILE_MAP_READ,profile.input_mapping_bytes),output(ho.value,FILE_MAP_WRITE,sizeof(Output)+profile.reply_limits.bytes);
        const auto* raw=static_cast<const Input*>(input.value);if(!raw->length || raw->length>profile.input_limits.bytes)invalid(profile,"input_size");
        const std::string bytes(reinterpret_cast<const char*>(raw+1),raw->length);const auto h=json::parse(bytes,profile.input_limits);header(h,profile);
        if(text(h,"host_id")!=security.host_id || text(h,"code_sha256")!=image.digest)invalid(profile,"worker_code");
        Handle payload;if(profile.payload_bytes)payload=Handle(argument_handle(argv[7]));
        auto* value=static_cast<Output*>(output.value);auto collector=factory(h,[value]{InterlockedExchange(&value->entered,1);},payload.value);signal(ha.value);
        if(WaitForSingleObject(hg.value,1000)!=WAIT_OBJECT_0)return 4;
        const auto snapshot=collector([&]{return WaitForSingleObject(hc.value,0)==WAIT_OBJECT_0;});
        auto reply=h;reply.fields.erase("policy");reply.fields.erase("provider_input");reply.put("schema",V::string(profile.reply_schema)).put("request_digest",V::string(hash(bytes)))
            .put("pid",number(GetCurrentProcessId())).put("created",V::string(process_created(GetCurrentProcess()))).put("snapshot",snapshot);
#if defined(DISKED_NT_NAMESPACE_WORKER_TESTING) || defined(DISKED_NT_OBSERVATION_WORKER_TESTING)
        const auto fault=field(h,"provider_input").find("reply_fault");const auto mode=fault?fault->text:"";
        if(mode=="capture")reply.put("capture_epoch",V::string("0"));if(mode=="worker")reply.put("worker_epoch",V::string("stale-worker"));
        if(mode=="code")reply.put("code_sha256",V::string(std::string(64,'0')));if(mode=="request")reply.put("request_digest",V::string(std::string(64,'0')));
        if(mode=="scope")reply.put("scope",V::string("wrong-profile"));if(mode=="host")reply.put("host_id",V::string("wrong-host"));
        if(mode=="observer")reply.put("observer_epoch",V::string("wrong-observer"));if(mode=="attempt")reply.put("attempt_id",V::string("wrong-attempt"));
        if(mode=="pid")reply.put("pid",V::string("0"));if(mode=="created")reply.put("created",V::string("0"));
        if(mode=="shape")reply.fields["snapshot"].put(profile.records_field,V{});if(mode=="status")reply.fields["snapshot"].put("status",V::string("invented"));
        if(mode=="claims")reply.fields["snapshot"].fields["claims"].put("physical_admission",V::boolean_value(true));if(mode=="schema")reply.put("schema",V::string("unknown-producer"));
        if(mode=="capacity")reply.fields["snapshot"].fields["resources"].items[0].fields["components"].fields["length"].fields["data"].put("length_bytes",V::string("1"));
#endif
        const auto serialized=json::dump(reply,profile.reply_limits),digest=hash(serialized);value->length=static_cast<DWORD>(serialized.size());
        std::memcpy(value+1,serialized.data(),serialized.size());std::memcpy(value->digest,digest.data(),digest.size());MemoryBarrier();InterlockedExchange(&value->ready,1);
#if defined(DISKED_NT_NAMESPACE_WORKER_TESTING) || defined(DISKED_NT_OBSERVATION_WORKER_TESTING)
        if(mode=="digest")value->digest[0]=value->digest[0]=='0'?'1':'0';if(mode=="hold")Sleep(500);
#endif
        return 0;
    }catch(const std::exception&){return 3;}
}
int observation_worker_role(int argc,wchar_t** argv,const ObservationWorkerProfile& profile,const ObservationFactory& factory){
    if(profile.payload_bytes)return 2;
    return observation_worker_role(argc,argv,profile,PayloadObservationFactory([&](const V& h,const std::function<void()>& notify,HANDLE){return factory(h,notify);}));
}
}}
