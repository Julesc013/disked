# DiskEd: current status and one-week execution plan

**Review date:** 19 October 2026, Australia/Melbourne.  
**Planning window:** Monday 19 October through Sunday 25 October 2026.  
**Product:** Julesc013/disked, not AIDE or FacMan.  
**Decision:** Continue the existing implementation. Close DE-W105's current qualification, fix DE-W106's evidence completeness and workspace routing, then run DE-W107. Do not restart the bootstrap or redesign the ownership tree.

## 1. Pinned repository state

| Ref | Commit | Meaning |
|---|---|---|
| main | `98b7573935c07d575d9500849662b3cafcfc9ee1` | Integrated checkpoint through DE-W104 and its retained evidence |
| dev | `9556b090b974489847683b801e6558af0dfb046f` | Active DE-W105 and guest qualification/fixture repairs |
| goal/disked-0.1.0 | `dd4846591e39a26b86f928870091fff0302e9533` | Historical goal branch; not the active development branch |

The heads were checked twice during this review and did not change. The dev commit is dated 18 October 2026, 10:49:21 UTC. GitHub's releases collection was empty at review time. Branch metadata reported these branches unprotected. [R1, R2]

DiskEd is substantially beyond the first native bootstrap. It is a Windows image/fake development workbench with working shared interfaces and many source-bound test results. It is not yet a qualified physical-disk manager or a complete cross-platform release. [R3, R4]

The programme explicitly retains **all platforms and storage operations specified at base `40ac8ec`** as the original 0.1.0 goal. This week's checkpoint does not redefine that scope or claim to finish it. Local implementation, tests, agent review, dev pushes and tested main integration are already recorded as authorized; owner acceptance, release publication and production storage authority remain separate. An active programme record is not proof that a live worker is currently running. [R4]

## 2. What is implemented

| Area | Existing implementation | Remaining distinction |
|---|---|---|
| Product executable | Native Windows single-entrypoint composition, build identity, help and actual command discovery | Not every platform or download composition qualified |
| CLI and machine interface | Descriptor parser, flexible option placement, aliases, contextual help, JSON/NDJSON, bounded framing | Per-command admission and other-platform qualification remain separate |
| Interactive interfaces | Native-console screen/linear TUI, explicit command shell, Win32 GUI and common typed actions | Screen-reader, high-contrast-on, per-monitor DPI, additional terminals and other OS evidence are incomplete |
| Fake operation runtime | Self-spawned workers, persistent identities, inspect/cancel/watch/reconnect, bounded processes and uncertain outcomes | Not a production privileged broker or physical-storage journal |
| Portable core | Checked ranges, byte views, endian handling, C90 primitives, MBR/EBR/GPT readers | Readers and supplied-byte tests do not admit writers |
| Ordinary image work | Public raw-file inspection and map verification; granted ordinary-file acquisition, cancellation/resume and verification | Not live physical-device acquisition or application-consistent backup |
| Evidence/reporting | Recorded acquisition/verification cases, report export and history/worker work | Full custody/authentication, physical and platform claims remain open |
| FAT/exFAT | Bounded metadata/allocation/directory readers; constrained ordinary-image FAT recursive extraction | Not universal filesystem recovery, mutation or semantic preservation |
| NTFS | Boot/FILE handling, attributes, runlists, attribute lists, bounded stream/record closure, directory-index observations, names/correspondence and uppercase-table work | Full namespace/collation/lookup/content is not established; no general NTFS repair/write capability |
| Windows storage integration | Private injected namespace, query, identity/layout, owned-reader and cached frontend work | Native live/provider/public admission remains a major unfinished boundary |
| Delivery | Artifact-completeness checker and bounded UniSetup source-consumer/carrier fixtures | Not a complete installed SDK/lifecycle or public installer release |
| Development environment | Working bounded Windows 10 guest setup, source transport, compiler/Python probes, scratch-cap evidence and private Win32 qualification | Full current x64 product qualification still pending |

Sources: current native guide, source map, TODO, programme and development plan. Some entries are public development commands; others are private prototypes. Do not collapse the distinction. [R3-R7]

## 3. What the test results actually support

### Integrated DE-W104 evidence

The programme retains exact native source `c460a35c67878cacda63b10561be9629b7370f1d`: 177/177 x64 native groups, 68 standalone headers and 14 executable/import observations, plus an 18-group private Win32 slice. This is evidence for that source and campaign, not a blanket pass for dev. [R4, R8]

### Earlier DE-W105 candidate

TODO records `fcd7a4a5` passing 178 x64 groups and a tooling run described as 253 tests with two skips. Subsequent shared-header, fixture and guest-harness changes mean this earlier run cannot certify the present candidate. [R6]

### Latest private Win32 campaign

Guest attempt 20 at exact source `c667318e258db237b56f103343360d1457dcb2c7` passed all 18 private Win32 groups, 12 standalone headers and nine executable/import observations. The directory-file group completed all 551 calls. The campaign preserved the named-lease ACL test and both sparse-symlink generations. [R9]

Peak scratch allocation was 72,967,178 bytes, approximately 69.6 MiB. Its 1,131,348-byte compressed evidence archive binds 736,549,188 original bytes in 2,956 entries. Cleanup and unchanged recorded host backing-file length are documented; unchanged file length is not a claim about reclaimed physical allocation. [R9]

### Still open

The same-source, all-target, current 178-group x64 product gate is required before integrating the shared product changes into main. A private x86/Win32 pass is not a full Win32 product pass and is not a substitute for that x64 gate. [R9]

No overall completion percentage is defensible: work units have unequal size and assurance scope, and the original goal spans many unqualified platforms and storage operations.

## 4. Immediate critical path

### DE-W105 — complete the existing candidate

1. Qualify the already-specified ordinary, non-AppContainer, non-elevated confined worker profile. Its expectation file currently says `planned-not-implemented`.
2. Prove protected user-only product records remain usable without widening their ACLs merely to make AppContainer tests pass.
3. Demonstrate the initial storage cap, outside-write denial, process retirement and cleanup using the existing guest authority.
4. Finish routing legacy fixtures into managed scratch without changing logical input bytes or weakening assertions.
5. Run a representative real build/store journey, then the current full x64 gate, standalone headers, C90/import checks and applicable tooling/context checks.
6. Integrate tested, agent-reviewed dev into main under the existing workflow.

The worker-profile implementation is not already complete just because guest administrative setup and private Win32 tests passed. Keep coordinator administration separate from the product's actual test token. [R4, R9, R10]

### DE-W106 — make reference evidence trustworthy

The current comparator can return `adapter_controls_passed=true` for missing external evidence, inconsistent fixture hashes or duplicate records. This review independently reproduced four forms of that problem using the exact 2,911-byte module, whose Git blob hash was verified before execution. [R11]

Define the expected fixture/participant/observation set before comparison. Require complete identities, counts, unique observation keys and appropriate failure/refusal records. Missing evidence cannot become success. A declared participant refusal can be a complete observation; it need not be a successful parse.

Migrate the old differential coordinator away from historical unbounded `.aide-local` output and prove bounded cleanup. Do not rerun its old recipe first. This repairs a validator weakness; it does not establish that every historical differential campaign was invalid. [R12]

### DE-W107 — execute the four planned reference cases

Use valid MBR, valid GPT, damaged primary GPT, and conflicting valid GPT copies. Bind the exact fixture recipe and participant copies to both Windows API and Disk Management UI observations. Retain the Windows build, identities, before/after bytes, refusals and disagreements. API-only observations do not satisfy a declared API-plus-UI campaign.

Use only owned disposable guest virtual media under the applicable grant. Reference mounting can change media; capture that rather than presuming a read-only UI caused no changes. REA stays optional and is not a prerequisite. [R12]

## 5. Proposed allocation for 19-25 October

These are priority slots, not a guarantee that each will finish within a day. Assumption: the existing guest/toolchain remains available and one primary writer can work with an independent review lane. Preserve the original programme and authorization boundaries.

| Day | Primary task | Exit evidence |
|---|---|---|
| Mon 19 | Qualify the ordinary confined worker; finish fixture routing and representative build/store preflight | Actual token properties, protected-record success, cap/outside-write denial and clean owned retirement |
| Tue 20 | Complete DE-W105 same-source x64 qualification; repair only demonstrated regressions | Full current gate, exact source/artifact identity, private regression applicability, reviewed main integration |
| Wed 21 | DE-W106 completeness/identity regressions and bounded coordinator migration | Missing, duplicate, mismatched and interrupted evidence cannot report complete controls; cleanup verified |
| Thu 22 | Prepare and execute DE-W107 on the owned generated virtual media | Four recipes, exact API/UI participant identities and bounded raw observations |
| Fri 23 | Replay/analyse DE-W107; translate findings into the existing DE-W030/035 contracts | Reproducible findings/refusals, independent expectations and narrowly justified implementation changes |
| Sat 24 | Exercise one coherent image-inspection/acquisition/verification/report journey across existing interfaces; fix high-value integration defects | Actual shared-interface results and precise limitations; no speculative new GUI framework |
| Sun 25 | Freeze the checkpoint, run final applicable qualification, verify archive completeness and synchronize docs/work state | Reproducible internal development package, source-bound results, current main and exact next work |

**Minimum useful outcome:** DE-W105 unblocked and integrated, DE-W106 repaired, and reliable bounded qualification.

**Intended outcome:** also complete the four-case Windows reference campaign and retain a coherent internal Windows image-workbench checkpoint.

**Stretch outcome:** the first tightly scoped live Windows read-only observation in the disposable virtual-media environment, through the existing DE-W030 ownership and admission path. Do not call it general physical-device support.

If early qualification takes longer, retain its actual blockers and defer later slots. Do not relax limits, skip required UI observations or declare a partial campaign complete to preserve the calendar.

## 6. Remaining product work beyond the week

- Real Windows storage discovery/topology/provider admission and stable identity on exact target profiles.
- A complete NTFS namespace/lookup/content design and implementations where selected; current name-order observations are not that capability.
- Application/snapshot consistency and real backing topology, failing-media and physical persistence evidence for acquisition.
- Accepted production journal/durability and privileged-executor contracts; image/table/filesystem writers, real repair/move/resize/format/conversion capabilities.
- Offline continuation, system/boot/BitLocker/WinRE work, cross-boot identity and power-loss recovery.
- Full FAT/exFAT/NTFS fidelity and further filesystems, arrays, pools, virtual images and enterprise/shared-storage coordination.
- XP/7/11/ARM64 and broader terminal/GUI/accessibility qualification. Win32 under a modern guest does not prove XP.
- DOS, JC-DOS/Carbon, OS/2, historical Windows, additional GUI systems, tape, optical, flux and broader architectures.
- Live AIDE interoperability and installed Universal Setup/servicing profiles, beyond the current passive/fixture work.
- Owner acceptance, original-code licensing decision, applicable release qualification and publication authorization.

These remain part of the recorded goal. A weekly internal candidate is not a renamed or reduced final 0.1.0 release. [R3-R7]

## 7. How to maximize useful throughput

Use one native campaign at a time in the shared guest. A separate reviewer can inspect code/contracts/evidence without launching a second campaign or touching the writer's workspace. Preserve the account and host rules in current AGENTS.md; do not repeatedly set up UAC or broaden guest privileges to sidestep the ordinary-worker proof. [R13]

Current limits are 32 MiB for local metadata, 1 GiB aggregate disposable work, 20,000 entries and 20 GiB free-space floors on involved volumes, together with the demonstrated filesystem cap. Native fixture size means allocated bytes as well as logical length. Preserve full byte/hash semantics when using sparse files. Keep generators and compact evidence, not duplicate build trees and raw captures. [R9, R13]

Run impact-selected checks during iteration and reuse earlier results only when exact input identity and evidence applicability justify it. Changing the runner or test environment can invalidate a qualification claim even when product bytes are unchanged. Run a clean final campaign for the selected candidate; do not rerun every historical version after every patch.

Do not spend the week redoing model shopping or building a universal orchestrator. Use an already functioning, permitted worker route and deterministic local tests. Preserve service interruptions separately from environment failures and actual test failures. Review the existing AIDE pin as its policy calls for on 19 October, but do not make an unrelated runtime migration a prerequisite. [R5]

## 8. Small documentation corrections that prevent repeated work

The repository currently mixes chronological progress with active instructions. Keep history, but add or maintain one short authoritative current snapshot resolving source, public/private availability, qualification and next work.

A specific current drift: `docs/code-structure.md` describes `.aide-local/` as holding builds and artifacts, while AGENTS.md now restricts it to small metadata and forbids build trees there. The old native-bootstrap bare CMake examples should be clearly labelled historical or redirected to the current managed guest workflow. Fix these contradictions rather than adding another architecture hierarchy. [R7, R13, R14]

Owner acceptance remains pending, but the explicit programme grant already permits local continuation after tests and agent review. Do not send workers back to DE-W000/DE-W010 as though no code exists. Public release and privileged storage gates remain separate. [R4]

Retain `source/portable`, `source/runtime`, `source/providers`, `source/platform`, and `source/apps/disked`. No evidence from this status review justifies replacing that tree, introducing a universal frontend superclass or copying filesystem engines wholesale. [R14]

## 9. Suggested persistent goal text

> Advance DiskEd from the current DE-W105 checkpoint toward a reproducibly qualified Windows image-workbench checkpoint. Read the current AGENTS.md and programme at one pinned revision; do not restart the bootstrap or redefine full 0.1.0. Finish ordinary confined-worker and managed-fixture qualification, complete the applicable current native/tooling gate and integrate reviewed changes. Then complete DE-W106 before DE-W107. Keep all current resource, account, host and storage boundaries. Preserve failed attempts and exact source/evidence applicability; do not widen protected product ACLs or weaken assertions to pass tests. Reuse unchanged verified work where permitted. Keep current state, test identities and the next safe task resumable. End each selected checkpoint with actual artifacts and results, not another generalized readiness review. Release publication, customer media and production physical storage require their separate gates.

This report is planning advice, not an execution grant or a started automation.

## 10. Review scope

Read live GitHub branches, current dev/main programme snapshots, README, TODO, development/native/source/structure/reference guides, guest qualification evidence and the ordinary-token candidate. Read and independently executed the exact differential comparator with four in-memory synthetic inputs. No physical devices or network targets were tested. No full specification suite, CMake/native suite, live guest or installer was run. No repository, branch protection, acceptance record or remote artifact was changed.

A full archive download for local inspection failed because the container could not resolve codeload.github.com. GitHub connector reads succeeded. Reported native counts are retained repository evidence, not reruns in this review.

## References

All file references below are pinned, not floating main/dev links.

- R1: [Branch heads](https://api.github.com/repos/Julesc013/disked/branches?per_page=100), observed 2026-10-19; [dev metadata](https://github.com/Julesc013/disked/commit/9556b090b974489847683b801e6558af0dfb046f).
- R2: [Releases collection](https://api.github.com/repos/Julesc013/disked/releases?per_page=5), empty when reviewed.
- R3: [README](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/README.md).
- R4: [Active development programme](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/.aide/programmes/disked-0.1.0.json).
- R5: [Development plan](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/docs/development-plan.md).
- R6: [TODO](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/TODO.MD).
- R7: [Native build/interface guide](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/docs/native-bootstrap.md).
- R8: [Integrated programme](https://github.com/Julesc013/disked/blob/98b7573935c07d575d9500849662b3cafcfc9ee1/.aide/programmes/disked-0.1.0.json).
- R9: [Guest campaign, including attempt 20](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/.aide/evidence/2026-10-18-guest-build/README.md).
- R10: [Ordinary-token candidate](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/.aide/evidence/2026-10-18-guest-build/ordinary-token-expectations.json).
- R11: [Exact comparator](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/tests/differential/compare.py).
- R12: [Windows reference plan](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/docs/windows-reference.md).
- R13: [Current contributor/worker instructions](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/AGENTS.md).
- R14: [Code structure](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/docs/code-structure.md); [source map](https://github.com/Julesc013/disked/blob/9556b090b974489847683b801e6558af0dfb046f/docs/source-map.md).
