add_test(qualification.receipt "C:/ProgramData/DiskEd/python314/python.exe" "-c" "raise SystemExit(0)")
