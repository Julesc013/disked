import json,pathlib,sys
sys.path.insert(0,sys.argv[1]);sys.path.insert(0,sys.argv[2])
from support.tempdir import managed_directory
from test_ntfs_file import size_fixture,record_sparse_fixture,prepared_symlink,file_digest,SPARSE_OBSERVATIONS,PREPARED_SYMLINK_OBSERVATIONS
with managed_directory(prefix='native-preflight-') as directory:
    source=pathlib.Path(directory)/'source.img'
    with source.open('wb') as stream:
        size_fixture(stream,5*1024*1024*1024+4096)
        stream.seek(5*1024*1024*1024);stream.write(b'owned high data')
        record_sparse_fixture(stream,5*1024*1024*1024+4096)
    with source.open('rb') as stream:
        assert stream.read(32)==bytes(32)
        stream.seek(5*1024*1024*1024);assert stream.read(15)==b'owned high data'
    source.unlink()
    for iteration in range(2):
        with source.open('wb') as stream:
            size_fixture(stream,40960000)
            stream.seek(4096);stream.write(b'original independent source '+bytes([iteration]))
            if not iteration:stream.seek(40959996);stream.write(b'tail')
        before=file_digest(source);target,link=prepared_symlink(source)
        assert link.is_symlink() and link.resolve()==target
        assert file_digest(source)==before==file_digest(target)
        assert PREPARED_SYMLINK_OBSERVATIONS[-1]['allocated_bytes']<=16777216
        assert PREPARED_SYMLINK_OBSERVATIONS[-1]['copied_nonzero_block_bytes']<=131072
assert not source.exists() and len(PREPARED_SYMLINK_OBSERVATIONS)==2
print(json.dumps(dict(status='pass',sparse=SPARSE_OBSERVATIONS,prepared=PREPARED_SYMLINK_OBSERVATIONS,source_removed=True)))
